Unit II · UAV Data Collection & Processing Methods
Google Colab notebooks + supporting data
==================================================

Each notebook matches one code snippet from the Unit II playground page.

HOW TO RUN IN GOOGLE COLAB
--------------------------
1. Go to https://colab.research.google.com  ->  File  ->  Upload notebook
   and choose one of the .ipynb files below.
2. Run the cells top to bottom (or Runtime > Run all).
3. When a cell asks you to upload a file, pick the matching data file from
   this pack (see the mapping below). If you skip the upload, every notebook
   auto-generates a stand-in scene so it still runs.

NOTEBOOKS  ->  DATA FILE(S) NEEDED
----------------------------------
09_read_write_images.ipynb     aerial_scene.jpg, aerial_scene.png
09_read_write_video.ipynb      flight.mp4
10_color_spaces.ipynb          aerial_scene.jpg
11_image_filters.ipynb         aerial_scene.jpg
12_edge_detection.ipynb        aerial_scene.jpg
13_histogram_clahe.ipynb       aerial_hazy.jpg
14_contours_segmentation.ipynb aerial_scene.jpg
15_haar_cascade.ipynb          none (uses a built-in public-domain sample,
                                     or upload your own photo with faces)

NOTES
-----
* OpenCV, NumPy, Matplotlib and scikit-image are pre-installed in Colab.
* cv2.imshow() cannot be used in Colab (no window server); the notebooks
  display images inline with Matplotlib via a small show() helper instead.
* The data files are a synthetic aerial "ortho" scene (field with crop rows,
  a road, buildings, trees, a pond and two vehicles) generated for teaching.
