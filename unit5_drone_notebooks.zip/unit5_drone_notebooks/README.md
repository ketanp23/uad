# Unit V · Unsupervised & Reinforcement Learning for UAV — Colab Notebooks

Nine self-contained notebooks, one per technique in the interactive study page.
Pure **NumPy + Matplotlib** for every core cell — **no GPU, no downloads, no datasets**.
Each notebook writes a shared `drone_synth5.py` (synthetic data + tiny UAV
environments) in its first cell and imports it, so any notebook runs standalone.

## Notebooks
| # | File | Technique |
|---|------|-----------|
| 00 | `00_synthetic_drone_data.ipynb` | The shared data + GridWorld MDP |
| 01 | `01_kmeans_clustering.ipynb` | K-means from scratch + elbow |
| 02 | `02_anomaly_detection.ipynb` | Distance-based scores, threshold sweep, precision/recall |
| 03 | `03_self_organizing_map.ipynb` | Kohonen SOM unfolding onto a ring |
| 04 | `04_swarm_boids.ipynb` | Boids flocking + coverage vs fleet size |
| 05 | `05_q_learning.ipynb` | Tabular Q-learning, value map + greedy policy |
| 06 | `06_deep_q_network.ipynb` | Replay vs online stability; optional PyTorch DQN + target net |
| 07 | `07_ppo.ipynb` | Clipped policy-gradient update; clip vs stability |
| 08 | `08_collision_free.ipynb` | Multi-UAV goal-seeking + avoidance; safety-vs-path trade-off |

## Running
- **Google Colab** — upload a notebook and Run all. Cells marked *(optional · GPU)*
  in notebook 06 use PyTorch; switch to a GPU runtime or just skip them — the NumPy
  demo above carries the lesson.
- **Locally** — `pip install numpy matplotlib` (plus `scikit-learn`, `torch` for the
  optional cells), then `jupyter notebook`.

## Notes
- All figures use synthetic data and are illustrative teaching values, not benchmarks.
- `drone_synth5.py` mirrors the maths in the interactive page's playgrounds so the
  notebook numbers line up with what you see on screen.
