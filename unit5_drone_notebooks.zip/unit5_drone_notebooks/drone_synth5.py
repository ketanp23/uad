"""
drone_synth5.py
===============
Synthetic data and tiny UAV environments for the Unit V
"Unsupervised & Reinforcement Learning for UAV" notebooks. Pure NumPy,
deterministic via seeds, no downloads. Mirrors the interactive HTML playgrounds.

  detection_clusters()        -> unlabelled 2-D detections        (clustering)
  telemetry_with_anomalies()  -> normal points + injected outliers (anomaly)
  ring_manifold()             -> a ring-shaped 2-D distribution    (SOM)
  nav_action_rewards()        -> reward per {N,E,S,W} action       (PPO)
  GridWorld                   -> a small walled grid MDP           (Q-learning, DQN)
  boids_step()                -> one flocking update               (swarm)
  fleet_step()                -> one collision-avoidance update    (collision-free)
"""
import numpy as np

ACTIONS = ["North", "East", "South", "West"]        # dy,dx below
_DIRS   = np.array([[0, -1], [1, 0], [0, 1], [-1, 0]])   # (dx,dy) for N,E,S,W

def rng(seed=0):
    return np.random.default_rng(seed)

# ------------------------------------------------------------------ #
# unsupervised data
# ------------------------------------------------------------------ #
def detection_clusters(k=4, per=32, seed=1, W=460, H=320):
    """Unlabelled 2-D detections drawn from k Gaussian blobs.
    Returns X (N,2) and the (hidden) true blob id for reference only."""
    r = rng(seed)
    centres = np.array([[110, 110], [330, 90], [220, 240], [360, 250], [90, 250], [420, 150]])[:k]
    X, true = [], []
    for i, c in enumerate(centres):
        pts = c + r.normal(0, [34, 30], (per, 2))
        X.append(pts); true += [i] * per
    X = np.clip(np.vstack(X), 8, [W - 8, H - 8])
    return X.astype(float), np.array(true)

def telemetry_with_anomalies(n_normal=140, seed=2, W=460, H=320):
    """Normal flight telemetry (one Gaussian cloud) + a handful of anomalies.
    Returns X (N,2) and is_anom (bool N,)."""
    r = rng(seed)
    normal = np.column_stack([r.normal(230, 55, n_normal), r.normal(160, 45, n_normal)])
    anom = np.array([[60, 60], [400, 70], [70, 270], [410, 260], [240, 300]], float)
    X = np.clip(np.vstack([normal, anom]), 8, [W - 8, H - 8])
    is_anom = np.array([False] * n_normal + [True] * len(anom))
    return X, is_anom

def ring_manifold(n=260, seed=3, W=460, H=320):
    """A ring-shaped distribution — a non-trivial manifold for a SOM to cover."""
    r = rng(seed)
    a = r.uniform(0, 2 * np.pi, n); rad = 90 + r.normal(0, 14, n)
    return np.column_stack([W / 2 + np.cos(a) * rad * 1.35, H / 2 + np.sin(a) * rad])

def nav_action_rewards():
    """Reward for each nav action {N,E,S,W}; 'East' is best — the target the
    PPO policy should converge to."""
    return np.array([0.25, 0.95, 0.45, 0.15])

# ------------------------------------------------------------------ #
# GridWorld MDP  (Q-learning, DQN)
# ------------------------------------------------------------------ #
class GridWorld:
    """A small walled grid the UAV must cross. Same layout as the playground.
    Reward: -1 blocked/step, -0.4 per free move, +10 at the goal."""
    WALLS = {(2,1),(2,2),(2,3),(2,4),(4,0),(4,1),(4,2),(6,2),(6,3),(6,4),(6,5)}
    def __init__(self, GW=9, GH=6, start=(0,5), goal=(8,0)):
        self.GW, self.GH, self.start, self.goal = GW, GH, start, goal
        self.n_actions = 4
    def reset(self):
        self.s = self.start
        return self.s
    def step(self, s, a):
        dx, dy = _DIRS[a]
        nx, ny = s[0] + dx, s[1] + dy
        if nx < 0 or ny < 0 or nx >= self.GW or ny >= self.GH or (nx, ny) in self.WALLS:
            return s, -1.0, False                       # blocked: stay
        if (nx, ny) == self.goal:
            return (nx, ny), 10.0, True
        return (nx, ny), -0.4, False
    def states(self):
        return [(x, y) for x in range(self.GW) for y in range(self.GH)
                if (x, y) not in self.WALLS]

# ------------------------------------------------------------------ #
# swarm (Boids)
# ------------------------------------------------------------------ #
def boids_step(pos, vel, coh=0.45, ali=0.55, sep=0.60, W=480, H=320, vmax=2.4):
    """One flocking update for all drones. pos, vel are (N,2) arrays."""
    N = len(pos); new_vel = vel.copy()
    for i in range(N):
        d = np.linalg.norm(pos - pos[i], axis=1)
        near = (d < 80) & (d > 0)
        if near.any():
            centre = pos[near].mean(0) - pos[i]
            align  = vel[near].mean(0)
            close  = (d < 26) & (d > 0)
            separate = -(pos[close] - pos[i]).sum(0) if close.any() else np.zeros(2)
            new_vel[i] += centre*0.001*coh + align*0.05*ali + separate*0.02*sep
        # keep inside
        if pos[i,0] < 20: new_vel[i,0] += 0.3
        if pos[i,0] > W-20: new_vel[i,0] -= 0.3
        if pos[i,1] < 20: new_vel[i,1] += 0.3
        if pos[i,1] > H-20: new_vel[i,1] -= 0.3
        sp = np.linalg.norm(new_vel[i]) or 1
        if sp > vmax: new_vel[i] *= vmax/sp
    new_pos = np.clip(pos + new_vel, 4, [W-4, H-4])
    return new_pos, new_vel

def coverage(pos, W=480, H=320, cell=30):
    gx = (pos[:,0]//cell).astype(int); gy = (pos[:,1]//cell).astype(int)
    seen = set(zip(gx.tolist(), gy.tolist()))
    return len(seen) / ((W//cell)*(H//cell))

# ------------------------------------------------------------------ #
# collision-free fleet
# ------------------------------------------------------------------ #
def fleet_step(pos, goals, obstacles, safety=26, W=480, H=320, speed=2.2):
    """One collision-avoidance update: each agent seeks its goal while pushing
    off neighbours (with a tangential term) and obstacles. Returns new pos and
    the minimum pairwise separation this step."""
    N = len(pos); new = pos.copy(); min_sep = 1e9
    for i in range(N):
        to_goal = goals[i] - pos[i]; dg = np.linalg.norm(to_goal) or 1
        f = to_goal/dg
        for j in range(N):
            if j == i: continue
            dxy = pos[i] - pos[j]; dd = np.linalg.norm(dxy) or 1
            min_sep = min(min_sep, dd)
            if dd < safety + 30:
                mag = (1/max(dd-8, 4))*90
                rad = dxy/dd; f = f + rad*mag
                tan = np.array([-rad[1], rad[0]])
                f = f + tan*mag*0.5
        for (ox, oy, orad) in obstacles:
            dxy = pos[i] - np.array([ox, oy]); dd = np.linalg.norm(dxy) or 1
            if dd < orad + safety + 20:
                f = f + (dxy/dd)*(1/max(dd-orad, 4))*140
        mag = np.linalg.norm(f) or 1
        new[i] = np.clip(pos[i] + f/mag*speed, 4, [W-4, H-4])
    return new, min_sep

if __name__ == "__main__":
    X, t = detection_clusters(); print("clusters", X.shape, "blobs", t.max()+1)
    Xa, a = telemetry_with_anomalies(); print("anomalies", int(a.sum()), "of", len(Xa))
    print("ring", ring_manifold().shape, "| rewards", nav_action_rewards())
    g = GridWorld(); print("gridworld states", len(g.states()), "actions", g.n_actions)
