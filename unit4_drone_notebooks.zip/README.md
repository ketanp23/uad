# Unit IV · Deep Learning for UAV Vision — Colab Notebooks

Nine self-contained notebooks, one per algorithm in the interactive study page.
Each notebook writes its own copy of `drone_synth4.py` (synthetic nadir drone
imagery, pure NumPy — no downloads) and reproduces exactly what the matching
HTML playground illustrates.

| Notebook | Playground it supports | Core (CPU) | Optional (GPU) |
|---|---|---|---|
| `00_synthetic_drone_data` | the shared dataset | scenes, patches, features, masks | — |
| `01_ann_perceptron` | Neuron & Decision Boundary | perceptron, activations, XOR→MLP | PyTorch net |
| `02_cnn_convolution` | Convolution & Pooling | conv2d/pool from scratch, kernels | `torch Conv2d` check |
| `03_fpn_multiscale` | Feature Pyramid | level→size assignment + viz | torchvision FPN shapes |
| `04_hog_features` | HOG Descriptor | gradients, HOG star, HOG+classifier | scikit-image HOG |
| `05_conventional_vs_dl` | Conventional vs Deep | recall-vs-perturbation curves | torchvision augment |
| `06_segmentation` | Semantic vs Instance | semantic/instance/panoptic, mIoU | Detectron2 Mask R-CNN |
| `07_obstacle_avoidance` | Avoidance Planner | potential field, local minima, A* | — |
| `08_transfer_learning` | Transfer-Learning Strategy | freeze/data/domain simulation | ResNet-18 fine-tune |

## Run
Open any notebook in Google Colab and Run All. The core cells need only
`numpy` + `matplotlib`. Cells marked **(optional · GPU)** install and use
PyTorch / Detectron2 and are meant for a Colab GPU runtime; they self-skip if
the library is absent, so the notebook always completes.

All synthetic data is deterministic (seeded), so results are reproducible.
